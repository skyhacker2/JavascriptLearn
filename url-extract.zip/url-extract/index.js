exports = module.exports = require('./lib/extracter');

exports.version = '0.1.7';