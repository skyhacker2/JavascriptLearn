module.exports = (function () {
  "use strict"
  var urlExtract = require('../')();
  var fs = require('fs');

  fs.writeFile('./time.txt', new Date());
/*
  setTimeout(function(){
  	process.kill('SIGINT');
  }, 3000);
*/
  for (var i = 0; i < 1000; i++) {
	  urlExtract.snapshot('http://www.baidu.com', "./snapshot/baidu" + i + ".png", function (job) {
	  	console.log (new Date());
	  });
	}	
})();